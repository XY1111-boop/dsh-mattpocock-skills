# dsh-mattpocock-skills

把 **Matt Pocock 的 agent skills** 打包成一个 DSH bundle（DSH 插件包）。

- 上游：`mattpocock/skills` v1.3.1（`.claude-plugin/plugin.json` 里的 27 个官方技能）
- 本机 vendor 检出：`/home/li/.dsh/vendor/mattpocock-skills`
- 本包只做一件事：**再注册一个 `skill-filesystem` provider**，把包内 `skills/` 目录
  作为技能根挂进 DSH。没有 JS 运行时、没有依赖、没有构建步骤。

## 装

任选一条（都走 DSH 自己的插件管理器，不手改 profile 文件）：

1. **人侧（推荐）**：左侧边栏 **「插件」** 页 → **「添加插件」** → 填本目录路径
   `/home/li/dsh-mattpocock-skills`。
2. **模型侧**：在开着 `plugin_manager` 工具的会话里（`cordis` 预设默认开）：

   ```
   plugin_manager { action: "install_bundle", target: "/home/li/dsh-mattpocock-skills" }
   ```

   装完用 `plugin_manager { action: "list_bundles" }` 确认、`list_plugins` 看
   `mattpocock-skills` 这行的 `enabled` / `fiberPhase`。

安装即把包写进 profile 的 `dsh.profile.bundles`，并在 profile 的 patch 层生效。

## 装了什么

`cordis.patch.yml` 插入一行：

```yaml
- id: mattpocock-skills
  name: '@deepseek-ai/dsh-skill-filesystem'
  config:
    providerName: mattpocock-skills        # 必须换名，见下
    includeDefaultRoots: false
    customSkillDirs: [ <本包>/skills ]
```

- **为什么必须换 `providerName`**：每个预设都已用默认名 `filesystem` 注册过
  `skill-filesystem`，而 `@deepseek-ai/dsh-skill` 的 provider 表是 `NamedEntries`，
  重名直接抛 `a skill provider named "filesystem" is already registered`。
- **路径为什么可重定位**：用官方 idiom
  `createRequire(baseUrl).resolve('dsh-mattpocock-skills/package.json')` → dirname → `+/skills`，
  与 `@deepseek-ai/dsh-web-app/presets/cordis.patch.yml:147` 同形。所以 manifest 的
  `exports` 里留了 `"./package.json"`。
- **优先级**：`customSkillDirs` 是 `CUSTOM_RANK`，在 `~/.agents/skills`
  （`USER_AGENTS_RANK`）之前扫描，所以同名技能以本包为准。若本机还留着旧的
  `~/.agents/skills/<name>` 软链，那份只是没装包时的兜底，不会被读到两次。

## 27 个已挂载技能

engineering 20：ask-matt, codebase-design, code-review, diagnosing-bugs, domain-modeling,
grill-with-docs, grilling, grill-me, implement, implement-spec, improve-codebase-architecture,
pr, prototype, research, retro, setup-matt-pocock-skills, tdd, to-spec, to-tickets, triage,
wayfinder, wizard；productivity 7：handoff, teach, to-questionnaire, wait-what, writing-for-agents
（以 `.claude-plugin/plugin.json` 为准，共 27 个）。

首次使用前先跑一次 **`/setup-matt-pocock-skills`**：它会问你的 issue tracker、
triage 标签、领域文档位置，然后往仓库里写 `docs/agents/{issue-tracker,domain,triage-labels}.md`，
并在 `AGENTS.md` / `CLAUDE.md` 里补 `## Agent skills` 块。其余技能里有 6/3/2 处引用这三个文件。

## 随包附带但**默认不挂载**的 11 个技能

上游的 `in-progress/` 与 `misc/`（未发布桶），放在 `extra/`，目录名是 `<bucket>--<name>`：

```
in-progress/chief-of-staff            in-progress/claude-handoff
in-progress/loop-me                   in-progress/setup-ts-deep-modules
in-progress/writing-beats             in-progress/writing-fragments
in-progress/writing-shape             misc/git-guardrails-claude-code
misc/migrate-to-shoehorn              misc/scaffold-exercises
misc/setup-pre-commit
```

要用就再加一个目录（同一次 `insert` 里再加一条 `customSkillDirs` 项即可），
注意 `misc/git-guardrails-claude-code` 是 Claude Code 专用的钩子配置，在 DSH 里不适用。

## 更新 / 卸载

- 更新技能正文（从 vendor 检出重新同步）：`./dsh-refresh-skills.sh`。
  装好之后 `skill-filesystem` 在 watch 这个根，文件改动会被自动重扫。
- 卸载：插件页里移除该 bundle，或
  `plugin_manager { action: "remove_bundle", target: "dsh-mattpocock-skills" }`。

## DSH 技能目录的硬约束（本包已满足）

- 每个技能是根下**一个子目录 + `SKILL.md`**；
- frontmatter 必须有非空 `name` 与 `description`；
- `name` 必须匹配 `/^[a-z0-9]+(?:-[a-z0-9]+)*$/`；
- 调用策略键只能用 canonical 拼写 `disable-model-invocation` / `user-invocable`；
  上游用的 `disable-model-invocation: true` 正是 canonical 形式。

许可证：技能正文来自 MIT 许可的 `mattpocock/skills`，见上游 `LICENSE`。
