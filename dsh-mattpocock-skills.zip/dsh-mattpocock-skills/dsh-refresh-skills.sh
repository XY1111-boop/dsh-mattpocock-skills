#!/usr/bin/env bash
# 从本机 vendor 的 mattpocock/skills 检出重新同步技能正文到本包。
#   $ dsh-refresh-skills.sh [vendor-repo-dir]
# 默认 vendor 目录：/home/li/.dsh/vendor/mattpocock-skills
# 已挂载的 skills/ 会被整体替换；extra/ 同样重建。装好的 bundle 因 watch 会自动重扫。
set -euo pipefail

PKG_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
VENDOR="${1:-/home/li/.dsh/vendor/mattpocock-skills}"

[ -f "$VENDOR/.claude-plugin/plugin.json" ] || { echo "找不到 $VENDOR/.claude-plugin/plugin.json" >&2; exit 1; }

python3 - "$VENDOR" "$PKG_DIR" <<'PY'
import json, shutil, sys, pathlib
src, dst = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
man = json.loads((src / '.claude-plugin/plugin.json').read_text())

shutil.rmtree(dst / 'skills', ignore_errors=True)
(dst / 'skills').mkdir(parents=True)
names = []
for rel in man['skills']:
    d = src / rel.lstrip('./')
    if not (d / 'SKILL.md').is_file():
        continue
    shutil.copytree(d, dst / 'skills' / d.name)
    names.append(d.name)

shutil.rmtree(dst / 'extra', ignore_errors=True)
(dst / 'extra').mkdir(parents=True)
extras = []
for bucket in ('in-progress', 'misc'):
    bdir = src / 'skills' / bucket
    if not bdir.is_dir():
        continue
    for d in sorted(bdir.iterdir()):
        if (d / 'SKILL.md').is_file():
            shutil.copytree(d, dst / 'extra' / f'{bucket}--{d.name}')
            extras.append(f'{bucket}/{d.name}')

# 版本号跟随上游 plugin.json
man_path = dst / 'package.json'
pkg = json.loads(man_path.read_text())
pkg['version'] = man.get('version', pkg['version'])
man_path.write_text(json.dumps(pkg, indent=2, ensure_ascii=False) + '\n')

print(f"synced {len(names)} skills + {len(extras)} extras from {src} (version {pkg['version']})")
PY
